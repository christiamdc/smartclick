const mqtt = require('mqtt')
const CronJob = require('cron').CronJob
const mongoose = require('mongoose')
const {load_cron} = require('../helpers/load_cron')

const User = mongoose.model('user')

const keys = require('../config/keys')

function on(req, res){
  let client = mqtt.connect(keys.mqttURI,{
    username: req.user.email,
    password: req.user._id.toString().slice(-6).toUpperCase()
  })
  let message_exists = false
  client.on('connect', () => {
    client.subscribe('stat/'+ req.user.email.split('@')[0]+ '/'+ req.body.name+ '/POWER')
    client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'on')
  })
  client.on('message', (topic, message) => {
    message_exists = true
  })
  setTimeout(() => {
    client.end()
    if(message_exists){
      res.status(200).send({msg: 'Orden enviada'})
    }else{
      res.status(401).send({msg: 'No está autorizado o no se pudo establecer conexion con el dispositivo'})
    }
  }, 1000)
}

function off(req, res){
  let client = mqtt.connect(keys.mqttURI,{
    username: req.user.email,
    password: req.user._id.toString().slice(-6).toUpperCase()
  })
  let message_exists = false
  client.on('connect', () => {
    client.subscribe('stat/'+ req.user.email.split('@')[0]+ '/'+ req.body.name+ '/POWER')
    client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'off')
  })
  client.on('message', (topic, message) => {
    message_exists = true
  })
  setTimeout(() => {
    client.end()
    if(message_exists){
      res.status(200).send({msg: 'Orden enviada'})
    }else{
      res.status(401).send({msg: 'No está autorizado o no se pudo establecer conexion con el dispositivo'})
    }
  }, 1000)
}

function sch_on(req, res){
  if(req.body.day){
    let newJob = {
      gadget: req.body.name,
      type_of_job: 'on',
      hour: req.body.time,
      day: req.body.day
    }
    User.findOneAndUpdate({_id: req.user._id}, {'$push': {jobs: newJob}}, {'new': true})
      .then(this_user => {
        let job = new CronJob(new Date(req.body.day+ ' '+ req.body.time), () => {
          let client = mqtt.connect(keys.mqttURI,{
            username: req.user.email,
            password: req.user._id.toString().slice(-6).toUpperCase()
          })
          client.on('connect', () => {
            client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'on')
            client.end()
          })
          job.stop()
        }, () => {
          User.findOneAndUpdate({_id: req.user._id}, {'$pull': {jobs: {_id: this_user.jobs.slice(-1)[0]._id}}}).
            then(() => {
              load_cron()
            })
            .catch(err => console.log(err))
        }, false, 'America/Lima')
        job.start()
        global.crons.push({
          user: req.user._id,
          cron_id: this_user.jobs.slice(-1)[0]._id,
          gadget: req.body.name,
          type_of_job: 'on',
          day: req.body.day,
          hour: req.body.time,
          days: null,
          job: job
        })
        res.status(200).send({msg: 'ok'})
      })
      .catch(err => {
        console.log(err)
        res.status(500).send({msg: 'Internal Server Error'})
      })
  }
  if(req.body.days){
    let newDays = ''
    let init = true
    req.body.days.forEach(day => {
      if(init){
        newDays += day
        init = false
      }else{
        newDays += ','+day
      }
    })
    let newJob = {
      gadget: req.body.name,
      type_of_job: 'on',
      hour: req.body.time,
      days: newDays
    }
    User.findOneAndUpdate({_id: req.user._id}, {'$push': {jobs: newJob}}, {'new': true})
      .then(this_user => {
        let job = new CronJob('0 '+req.body.time.split(':')[1]+' '+req.body.time.split(':')[0]+' * * '+newDays, () => {
          let client = mqtt.connect(keys.mqttURI,{
            username: req.user.email,
            password: req.user._id.toString().slice(-6).toUpperCase()
          })
          client.on('connect', () => {
            client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'on')
            client.end()
          })
        }, null, false, 'America/Lima')
        job.start()
        global.crons.push({
          user: req.user._id,
          cron_id: this_user.jobs.slice(-1)[0]._id,
          gadget: req.body.name,
          type_of_job: 'on',
          day: null,
          hour: req.body.time,
          days: newDays,
          job: job
        })
        res.status(200).send({msg: 'ok'})
      })
      .catch(err => {
        console.log(err)
        res.status(500).send({msg: 'Internal Server Error'})
      })
  }
}

function sch_off(req, res){
  if(req.body.day){
    let newJob = {
      gadget: req.body.name,
      type_of_job: 'off',
      hour: req.body.time,
      day: req.body.day
    }
    User.findOneAndUpdate({_id: req.user._id}, {'$push': {jobs: newJob}}, {'new': true})
      .then(this_user => {
        let job = new CronJob(new Date(req.body.day+ ' '+ req.body.time), () => {
          let client = mqtt.connect(keys.mqttURI,{
            username: req.user.email,
            password: req.user._id.toString().slice(-6).toUpperCase()
          })
          client.on('connect', () => {
            client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'off')
            client.end()
          })
          job.stop()
        }, () => {
          User.findOneAndUpdate({_id: req.user._id}, {'$pull': {jobs: {_id: this_user.jobs.slice(-1)[0]._id}}}).
            then(() => {
              load_cron()
            })
            .catch(err => console.log(err))
        }, false, 'America/Lima')
        job.start()
        global.crons.push({
          user: req.user._id,
          cron_id: this_user.jobs.slice(-1)[0]._id,
          gadget: req.body.name,
          type_of_job: 'off',
          day: req.body.day,
          hour: req.body.time,
          days: null,
          job: job
        })
        res.status(200).send({msg: 'ok'})
      })
      .catch(err => {
        console.log(err)
        res.status(500).send({msg: 'Internal Server Error'})
      })
  }
  if(req.body.days){
    let newDays = ''
    let init = true
    req.body.days.forEach(day => {
      if(init){
        newDays += day
        init = false
      }else{
        newDays += ','+day
      }
    })
    let newJob = {
      gadget: req.body.name,
      type_of_job: 'off',
      hour: req.body.time,
      days: newDays
    }
    User.findOneAndUpdate({_id: req.user._id}, {'$push': {jobs: newJob}}, {'new': true})
      .then(this_user => {
        let job = new CronJob('0 '+req.body.time.split(':')[1]+' '+req.body.time.split(':')[0]+' * * '+newDays, () => {
          let client = mqtt.connect(keys.mqttURI,{
            username: req.user.email,
            password: req.user._id.toString().slice(-6).toUpperCase()
          })
          client.on('connect', () => {
            client.publish('cmnd/'+req.user.email.split('@')[0]+'/'+req.body.name+'/power', 'off')
            client.end()
          })
        }, null, false, 'America/Lima')
        job.start()
        global.crons.push({
          user: req.user._id,
          cron_id: this_user.jobs.slice(-1)[0]._id,
          gadget: req.body.name,
          type_of_job: 'off',
          day: null,
          hour: req.body.time,
          days: newDays,
          job: job
        })
        res.status(200).send({msg: 'ok'})
      })
      .catch(err => {
        console.log(err)
        res.status(500).send({msg: 'Internal Server Error'})
      })
  }
}

function cancel_sch(req, res){
  global.crons.forEach(cron => {
    if(cron.cron_id.toString() == req.params.id.toString()){
      User.findOneAndUpdate({_id: req.user._id}, {'$pull': {jobs: {_id: req.params.id}}})
        .then(() => {
          cron.job.stop()
          let index = global.crons.indexOf(cron)
          global.crons.splice(index, 1)
          res.redirect('/dashboard')
        })
        .catch(err => {
          console.log(err)
          res.redirect('/dashboard')
        })
    }
  })
}

function status(req, res){
  let client = mqtt.connect(keys.mqttURI, {
    username: req.user.email,
    password: req.user._id.toString().slice(-6).toUpperCase()
  })
  let message_string = ''
  client.on('connect', () => {
    client.subscribe('stat/'+ req.user.email.split('@')[0]+ '/'+ req.params.gadget+ '/POWER')
    client.publish('cmnd/'+ req.user.email.split('@')[0]+ '/'+ req.params.gadget+ '/power', '')
  })
  client.on('message', (topic, message) => {
    message_string = message.toString()
  })
  setTimeout(() => {
    client.end()
    if(message_string != ''){
      res.status(200).send({status: message_string})
    }else{
      res.status(401).send({msg: 'No está autorizado o no se pudo establecer conexion con el dispositivo'})
    }
  }, 2000)
}

module.exports = {
  on,
  off,
  sch_on,
  sch_off,
  cancel_sch,
  status
}
