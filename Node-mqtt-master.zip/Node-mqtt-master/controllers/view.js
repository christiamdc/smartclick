const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
const passport = require('passport')
const request = require('request')

const keys = require('../config/keys')
const User = mongoose.model('user')

function login(req, res){
  res.render('pages/login')
}

function signup(req, res){
  res.render('pages/signup')
}

function dashboard(req, res){
  if(req.user && req.user.admin){
    User.find({})
      .then(users => {
        res.render('pages/users', {
          page: 'dashboard',
          users: users
        })
      })
      .catch(err => {
        console.log(err)
        res.redirect('/')
      })
  }else{
    data = getData(req.user)
    res.render('pages/dashboard', {
      gadgets: data,
      page: 'dashboard'
    })
  }
}

function logout(req, res){
  req.logout()
  res.redirect('/')
}

function password(req, res){
  res.render('pages/password', {
    page: 'password'
  })
}

function create(req, res){
  res.render('pages/create',{
    page: 'create'
  })
}

function register(req, res){
  User.findOne({email: req.body.email})
    .then(user => {
      if(user){
        res.redirect('/')
      }else{
        let newU = {
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          email:req.body.email.toLowerCase(),
          password: req.body.password
        }
        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(newU.password, salt, (err, hash) => {
            if(err) throw err
            newU.password = hash
            User.create(newU)
              .then(user => {
                let options = {
                  url: 'https://api.cloudmqtt.com/api/user',
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json'
                  },
                  body: '{"username":"'+ user.email+ '","password":"'+ user._id.toString().slice(-6).toUpperCase()+ '"}',
                  auth: {
                    'user': '',
                    'pass': keys.mqttKEY
                  }
                }
                request(options, (err, response, body) => {
                  if(response.body == ''){
                    res.redirect('/')
                  }
                })
              })
              .catch(err => console.log(err))
          })
        })
      }
    })
    .catch(err => {
      console.log(err)
      res.redirect('/')
    })
}

function plogin(req, res, next){
  passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/',
    failureFlash: true
  })(req, res, next)
}

function pcreate(req, res){
  User.findOneAndUpdate({_id: req.body.user}, {'$push': {gadgets: req.body.name}}, {'new': true})
    .then(user => {
      let options = {
        url: 'https://api.cloudmqtt.com/api/acl',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: '{"type":"topic", "username":"'+ user.email+ '", "pattern": "cmnd/'+ user.email.split('@')[0]+ '/'+ req.body.name+ '/power", "read": true, "write": true}',
        auth: {
          'user': '',
          'pass': keys.mqttKEY
        }
      }
      request(options, (err, response, body) => {
        if (response.body == '') {
          options = {
            url: 'https://api.cloudmqtt.com/api/acl',
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: '{"type":"topic", "username":"'+ user.email+ '", "pattern": "stat/'+ user.email.split('@')[0]+ '/'+ req.body.name+ '/POWER", "read": true, "write": true}',
            auth: {
              'user': '',
              'pass': keys.mqttKEY
            }
          }
          request(options, (err, response, body) => {
            console.log(response.body)
            if(response.body == ''){
              res.redirect('/dashboard')
            }
          })
        }
      })
    })
    .catch(err => console.log(err))
}

function getData(user){
  let data = []
  if(global.crons.length == 0){
    user.gadgets.forEach(gadget => {
      data.push({gadget: gadget})
    })
  }else{
    let my_crons = []
    global.crons.forEach(cron => {
      if(cron.user.toString() == user._id.toString()){
        my_crons.push(cron)
      }
    })
    user.gadgets.forEach(gadget => {
      gadget_temp = {
        gadget: gadget,
        crons: []
      }
      my_crons.forEach(cron => {
        if(cron.gadget == gadget){
          if(cron.day == null){
            let sDays = cron.days.split(',')
            let days = ''
            sDays.forEach(day => {
              if(day == '1')  days += ' Lunes'
              if(day == '2')  days += ' Martes'
              if(day == '3')  days += ' Miércoles'
              if(day == '4')  days += ' Jueves'
              if(day == '5')  days += ' Viernes'
              if(day == '6')  days += ' Sábado'
              if(day == '0')  days += ' Domingo'
            })
            cron_temp = {
              cron_id: cron.cron_id,
              type_of_job: cron.type_of_job,
              hour: cron.hour,
              day: cron.day,
              days: days
            }
            gadget_temp.crons.push(cron_temp)
          }else{
            cron_temp = {
              cron_id: cron.cron_id,
              type_of_job: cron.type_of_job,
              hour: cron.hour,
              day: cron.day,
              days: cron.days
            }
            gadget_temp.crons.push(cron_temp)
          }
        }
      })
      data.push(gadget_temp)
    })
  }
  return data
  /*
  if(data.length == user.gadgets.length){
    return data
  }else{
    user.gadgets.forEach(gadget => {
      let found = false
      data.forEach(each_data => {
        if(each_data.gadget == gadget) found = true
      })
      if(!found) data.push({gadget: gadget})
    })
    return data
  }
  */
}

function cpass(req, res){
  User.findOne({_id: req.user._id})
    .then(user => {
      bcrypt.compare(req.body.old_password, user.password, (err, isMatch) => {
        if(err) console.log(err)
        if(isMatch){
          if(req.body.new_password != req.body.new_password2){
            req.flash('error', 'Las contraseñas no coinciden')
            res.redirect('/password')
          }else {
            bcrypt.genSalt(10, (err, salt) => {
              bcrypt.hash(req.body.new_password, salt, (err, hash) => {
                new_password = hash
                User.findOneAndUpdate({_id: req.user._id}, {password: new_password})
                  .then(user => {
                    req.flash('success', 'La contraseña se cambio satisfactoriamente')
                    res.redirect('/password')
                  })
                  .catch(err => console.log(err))
              })
            })
          }
        }else{
          req.flash('error', 'Contraseña antigua incorrecta')
          res.redirect('/password')
        }
      })
    })
    .catch(err => {
      console.log(err)
      res.redirect('/')
    })
}

module.exports = {
  login,
  signup,
  register,
  plogin,
  dashboard,
  logout,
  create,
  pcreate,
  password,
  cpass
}
