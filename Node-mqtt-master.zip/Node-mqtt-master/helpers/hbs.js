const moment = require('moment')

module.exports = {
  getMQTTPassword: function(arg){
    return arg.toString().slice(-6).toUpperCase()
  },
  getTopic(arg1, arg2){
    return arg1.toString().split('@')[0]+'/'+arg2.toString()
  },
  formatDate: function(date, format){
    return moment(date).format(format)
  },
  sum: function(a, b) {
    return a + b;
  },
  equals: function(arg1, arg2, options){
    return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
  },
  ifCond: function (v1, operator, v2, options) {
    if (v2 != null && v2 != undefined) {
      switch (operator) {
        case '==':
            return (v1 == v2) ? options.fn(this) : options.inverse(this);
        case '===':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '!=':
            return (v1 != v2) ? options.fn(this) : options.inverse(this);
        case '!==':
            return (v1 !== v2) ? options.fn(this) : options.inverse(this);
        case '<':
            return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=':
            return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>':
            return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=':
            return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&':
            return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||':
            return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default:
            return options.inverse(this);
      }
    } else {
      if(v1) {
        return operator.fn(this);
      } else {
        return operator.inverse(this);
      }
    }
  }
}
