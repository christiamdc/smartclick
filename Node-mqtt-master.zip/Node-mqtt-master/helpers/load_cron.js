const mongoose = require('mongoose')
const mqtt = require('mqtt')
const CronJob = require('cron').CronJob
const User = mongoose.model('user')

const keys = require('../config/keys')

module.exports = {
  load_cron: function(){
    global.crons = []
    User.find()
      .then(users => {
        users.forEach(user => {
          user.jobs.forEach(cron => {
            if(cron.day){
              let job = new CronJob(new Date(cron.day+ ' '+ cron.hour), () => {
                let client = mqtt.connect(keys.mqttURI,{
                  username: user.email,
                  password: user._id.toString().slice(-6).toUpperCase()
                })
                client.on('connect', () => {
                  client.publish('cmnd/'+user.email.split('@')[0]+'/'+cron.gadget+'/power', cron.type_of_job)
                  client.end()
                })
              }, null, false, 'America/Lima')
              job.start()
              global.crons.push({
                user: user._id,
                cron_id: cron._id,
                gadget: cron.gadget,
                type_of_job: cron.type_of_job,
                day: cron.day,
                hour: cron.hour,
                days: null,
                job:job
              })
            }else if(cron.days.length != 0){
              let job = new CronJob('0 '+cron.hour.split(':')[1]+' '+cron.hour.split(':')[0]+' * * '+cron.days, () => {
                let client = mqtt.connect(keys.mqttURI,{
                  username: user.email,
                  password: user._id.toString().slice(-6).toUpperCase()
                })
                client.on('connect', () => {
                  client.publish('cmnd/'+user.email.split('@')[0]+'/'+cron.gadget+'/power', cron.type_of_job)
                  client.end()
                })
              }, null, false, 'America/Lima')
              job.start()
              global.crons.push({
                user: user._id,
                cron_id: cron._id,
                gadget: cron.gadget,
                type_of_job: cron.type_of_job,
                day: null,
                hour: cron.hour,
                days: cron.days,
                job:job
              })
            }
          })
        })
      })
      .catch(err => console.log(err))
  }
}
