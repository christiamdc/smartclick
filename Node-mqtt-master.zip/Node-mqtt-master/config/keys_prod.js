module.exports = {
  mongoURI: process.env.MONGO_URI,
  mqttURI: process.env.MQTT_URI,
  mqttKEY: process.env.MQTT_KEY
}
