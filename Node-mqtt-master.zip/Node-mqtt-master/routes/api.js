const express = require('express')
const mongoose = require('mongoose')
const api = express.Router()

const apiController = require('../controllers/api')

// Enciende el dispositivo
api.post('/on', apiController.on)
// Apaga el dispositivo
api.post('/off', apiController.off)
// Programa un encendido
api.post('/sch_on', apiController.sch_on)
// Programa un apagado
api.post('/sch_off', apiController.sch_off)

// Cancela una programacion
api.get('/cancel_sch/:id', apiController.cancel_sch)
// Verifica si el dispositivo esta encendido o apagado
api.get('/status/:gadget', apiController.status)

module.exports = api
