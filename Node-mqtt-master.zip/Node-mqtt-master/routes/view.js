const express = require('express')
const view = express.Router()

const {
  ensureGuest,
  ensureAuthenticated,
  ensureAdmin
} = require('../helpers/dev_auth')

const viewController = require('../controllers/view')

// Muestra vista inicial antes de logeo
view.get('/', ensureGuest, viewController.login)
// Muestra vista de creacion de usuarios
view.get('/signup', /*ensureAdmin,*/ viewController.signup)
// Muestra vista luego de logeo
view.get('/dashboard', ensureAuthenticated, viewController.dashboard)
// Cierre de sesion
view.get('/logout', ensureAuthenticated, viewController.logout)
// Vista para cambiar password de usuarios
view.get('/password', ensureAuthenticated, viewController.password)

// Creacion de nuevo usuario
view.post('/signup', /*ensureAdmin,*/ viewController.register)
// Autenticacion
view.post('/', ensureGuest, viewController.plogin)
// Crear dispositivo
view.post('/create', ensureAdmin, viewController.pcreate)
// Cambiar password
view.post('/password', ensureAuthenticated, viewController.cpass)

module.exports = view
