const express = require('express')
const bodyParser = require('body-parser')
const exphbs = require('express-handlebars')
const flash = require('connect-flash')
const path = require('path')
const session = require('express-session')
const passport = require('passport')
const MongoStore = require('connect-mongo')(session)
const mongoose = require('mongoose')

// Cargar modelo
require('./models/User')

// Funcion para cargar los cron en cada reinicio del servidor
const {load_cron} = require('./helpers/load_cron')

// Cargar rutas
const view = require('./routes/view')
const api = require('./routes/api')

// Configuracion de passport
require('./config/passport')(passport)

const app = express()
// Cargar llaves que no deben estar en codigo
const keys = require('./config/keys')

// Funcion de ayuda en handlebars
const {
  formatDate,
  sum,
  equals,
  ifCond,
  getMQTTPassword,
  getTopic
} = require('./helpers/hbs')

// Configuracion de mongoose y base de datos
mongoose.Promise = global.Promise
mongoose.connect(keys.mongoURI,{
  useNewUrlParser: true
})
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err))

// Seteo de handlebars
app.engine('handlebars', exphbs({
  helpers: {
    formatDate: formatDate,
    equals: equals,
    sum: sum,
    if: ifCond,
    getMQTTPassword: getMQTTPassword,
    getTopic: getTopic
  },
  defaultLayout: 'main'
}))

app.set('view engine', 'handlebars')

// Configuracion tipica
app.use(bodyParser.urlencoded({
  extended: false
}))

app.use(bodyParser.json())
app.use(express.static(path.join(__dirname, 'public')))
app.use(session({
  secret: 'Mindtec-IOT',
  resave: true,
  saveUninitialized: false,
  store: new MongoStore({
    mongooseConnection: mongoose.connection
  }),
  cookie: {
    maxAge: 3600000
  }
}))

// Initialize passport
app.use(passport.initialize())
app.use(passport.session())
app.use(flash())
app.use(function(req, res, next){
  res.locals.success = req.flash('success')
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null;
  next();
});

app.use('/', view)
app.use('/api', api)

const port = process.env.PORT || 1400

app.listen(port, () => {
  load_cron()
  /*
  setTimeout(() => {
    console.log(global.crons)
  }, 2000)*/
  console.log('Server started at port '+port)
})
