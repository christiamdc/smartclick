const mongoose = require('mongoose')
const Schema = mongoose.Schema

const UserSchema = new Schema({
  first_name: String,
  last_name: String,
  email: String,
  admin: {
    type: Boolean,
    default: false
  },
  password: String,
  gadgets: [String],
  jobs: [{
    gadget: String,
    type_of_job: String,
    hour: String,
    day: String,
    days: String
  }]
})

mongoose.model('user', UserSchema)
